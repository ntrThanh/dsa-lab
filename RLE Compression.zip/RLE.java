public class RLE {
	
	/**
	 * Computes the length of the compression array.
	 * @param t a binary array
	 * @return an integer.
	 */
	public static int length(int[] t) {
		// TODO: Your code here
		return 0;
	}

	/**
	 * Compresses an array in RLE format and return the result.
	 * @param t
	 * @return compressed array.
	 */
	public static int[] compress(int[] t) {
		// TODO: Your code here
		return null;
	}

	/**
	 * Computes the length of the decompressed array.
	 * @param t
	 * @return an integer.
	 */
	public static int lengthInverse(int[] t) {
		// TODO: Your code here
		return 0;
	}
	
	/**
	 * Decompresses the array.
	 * @param t
	 * @return an array
	 */
	public static int[] decompress(int[] t) {
		return null;
	}
}
