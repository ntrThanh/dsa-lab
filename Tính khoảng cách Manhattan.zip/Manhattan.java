public class Manhattan{
    
    public int manhattan(int[][] m)
    {
        return -1;
    }
}