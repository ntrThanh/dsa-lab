public class NPuzzle{
    
    
    public Iterable<int[][]> neighbors(int[][] m) {
		return null;

	}
    
}