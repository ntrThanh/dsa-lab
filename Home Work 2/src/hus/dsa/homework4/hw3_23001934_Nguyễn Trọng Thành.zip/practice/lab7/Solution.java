package hus.dsa.homework4.practice.lab7;

public class Solution {
}
