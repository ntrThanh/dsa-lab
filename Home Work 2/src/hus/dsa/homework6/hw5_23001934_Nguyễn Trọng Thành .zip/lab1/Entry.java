package hus.dsa.homework6.lab1;

public interface Entry<K, E> {
    K getKey();
    E getValue();
}
