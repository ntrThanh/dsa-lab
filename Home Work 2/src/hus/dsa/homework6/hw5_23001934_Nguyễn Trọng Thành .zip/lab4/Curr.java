package hus.dsa.homework6.lab4;

public class Curr {
    public static void main(String[] args) {
        for (int i = 0; i < 50; i++) {
            System.out.print("-");
        }
    }
}
