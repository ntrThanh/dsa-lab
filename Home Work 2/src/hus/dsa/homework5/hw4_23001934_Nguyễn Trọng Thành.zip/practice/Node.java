package hus.dsa.homework5.practice;

public class Node {
    public int data;
    public Node left;
    public Node right;
}
